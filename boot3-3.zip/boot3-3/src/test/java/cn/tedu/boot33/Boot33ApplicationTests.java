package cn.tedu.boot33;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot33ApplicationTests {

    @Test
    void contextLoads() {
    }

}
