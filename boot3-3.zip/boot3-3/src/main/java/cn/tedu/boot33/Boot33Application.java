package cn.tedu.boot33;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot33Application {

    public static void main(String[] args) {
        SpringApplication.run(Boot33Application.class, args);
    }

}
